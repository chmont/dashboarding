# ==== CONFIG ====
$grafanaUrl = $env:Grafana_Url
$token = $env:Token

# ==== HEADERS ====
$headers = @{
    "Authorization" = "Bearer $token"
    "Content-Type"  = "application/json"
}

# ==== API CALL ====
$uri = $grafanaUrl + "apis/folder.grafana.app/v1beta1/namespaces/default/folders"
Write-Output $uri

$response = Invoke-RestMethod -Uri $uri -Headers $headers -Method Get

# ==== OUTPUT RESULTS ====
Write-Host "Folders found:`n"
$clientFolder = $env:Client_Name
Write-Host $clientFolder


foreach ($folder in $response.items) {
    # Filter only the desired folder
    if ($folder.spec.title -eq "$clientFolder") {

        $title = $folder.spec.title
        $uid   = $folder.metadata.name
        $uri = $grafanaUrl + "apis/folder.grafana.app/v1beta1/namespaces/default/folders/$uid"

        Write-Host "Title: $title"
        Write-Host "Folder UID: $uid"
        Invoke-RestMethod -Uri $uri -Header $headers -Method Delete
        Write-Host "-----------------------------"
        break
    }
}
