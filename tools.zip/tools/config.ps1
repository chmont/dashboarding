# config.ps1
# ----------
# Reads environment variables and builds a config hashtable used by all scripts.
# Returns a hashtable via implicit output (PowerShell returns the last expression).

# --- Read client name from env var ------------------------------------------
$clientName = $env:Client_Name

if ([string]::IsNullOrWhiteSpace($clientName)) {
    throw "Client_Name environment variable is missing."
}

# --- Read dashboards directory ----------------------------------------------
$dashboardsDir = $env:Dashboards_Dir

if ([string]::IsNullOrWhiteSpace($dashboardsDir)) {
    throw "Dashboards_Dir environment variable is missing."
}

# --- Read dashboard key from env var ----------------------------------------
# This is the switch that makes the flow dynamic.
# Examples:
#   overview  -> Client-Overview.json / acme-corp-overview.json
#   home      -> Client-Home.json     / acme-corp-home.json
#
# If not provided, default to "overview" to preserve current behavior.
$dashboardKey = if ($env:Dashboard_Key) { $env:Dashboard_Key.Trim().ToLower() } else { "overview" }

if ([string]::IsNullOrWhiteSpace($dashboardKey)) {
    throw "Dashboard_Key environment variable is missing."
}

# --- Build a URL/filesystem-safe version of the client name -----------------
# ToLower()         -> lowercase everything
# -replace pattern  -> swap any non-alphanumeric characters for hyphens
# .Trim('-')        -> remove leading/trailing hyphens
# Example: "Acme Corp" -> "acme-corp"
$safeName = $clientName.ToLower().Trim() -replace '[^a-z0-9]+', '-'
$safeName = $safeName.Trim('-')

# --- Build a display label from the dashboard key ---------------------------
# Used for Grafana titles and the template file naming convention.
# Example: overview -> Overview
#          home     -> Home
$dashboardLabel = if ($dashboardKey.Length -gt 1) {
    $dashboardKey.Substring(0,1).ToUpper() + $dashboardKey.Substring(1)
} else {
    $dashboardKey.ToUpper()
}

# --- Return the config hashtable --------------------------------------------
@{
    # Connection settings
    GrafanaUrl      = $env:Grafana_Url
    Token           = $env:Token
    Namespace       = if ($env:Namespace) { $env:Namespace } else { "default" }

    # Client info
    ClientName      = $clientName
    SubscriptionId  = $env:Subscription

    # Folder settings (subfolder under "Clients/")
    ParentFolder    = "Client-Homepages"
    FolderTitle     = "$clientName"
    FolderUid       = ""                # Blank -> looked up or created by create-folder.ps1

    # Dashboard directory structure
    #   dashboards/
    #     templates/    <- source of truth (never modified)
    #     output/       <- client-specific copies
    #     payloads/     <- API request bodies (for debugging)
    DashboardsDir   = $dashboardsDir
    TemplatesDir    = Join-Path $dashboardsDir "templates"
    OutputDir       = Join-Path $dashboardsDir "output"
    PayloadsDir     = Join-Path $dashboardsDir "payloads"

    # Dynamic dashboard settings
    DashboardKey    = $dashboardKey
    DashboardLabel  = $dashboardLabel
    SafeName        = $safeName

    # File paths
    # Template naming convention:
    #   Client-Overview.json
    #   Client-Home.json
    #   Client-Security.json
    SourceDashboard = Join-Path (Join-Path $dashboardsDir "templates") "Client-$dashboardLabel.json"
    OutputDashboard = Join-Path (Join-Path $dashboardsDir "output") "$safeName-$dashboardKey.json"
    PayloadFile     = Join-Path (Join-Path $dashboardsDir "payloads") "$safeName-$dashboardKey-submit-body.json"

    # Dashboard metadata
    DashboardTitle       = "$clientName-$dashboardLabel"
    DashboardDescription = "$clientName-$dashboardLabel"

    # Template variable settings
    # 0 = visible, 1 = label only, 2 = fully hidden
    HideSubVariable = 2
}
