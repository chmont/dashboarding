# ==== CONFIG ====
$grafanaUrl = $env:Grafana_Url.TrimEnd('/')
$token = $env:Token
$folder = $env:Client_Name

# ==== HEADERS ====
$headers = @{
    "Authorization" = "Bearer $token"
    "Content-Type"  = "application/json"
}

# ==== API CALL ====
$uri = "$grafanaUrl/apis/dashboard.grafana.app/v1beta1/namespaces/default/dashboards"
$response = Invoke-RestMethod -Uri $uri -Headers $headers -Method Get

$u = ""

# ==== OUTPUT RESULTS ====
Write-Host "Dashboards found:"
Write-Host $folder

foreach ($dash in $response.items) {
    $title = $dash.spec.title

    if ($title -eq "$env:Client_Name-$env:Dasboard_key") {
        $uid = $dash.metadata.name
        $url = "/d/$uid/$title"
        $u = $uid

        Write-Host "Title: $title"
        Write-Host "UID:   $uid"
        Write-Host ("URL:   {0}?var-sub=`$sub" -f $url)
        Write-Host "-----------------------------"
        break
    }
}

[pscustomobject]@{
    uid = $u
}

Write-Host "==========exiting=========="