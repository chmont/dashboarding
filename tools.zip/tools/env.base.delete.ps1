
$env:Grafana_Url     = ""           # Base URL, e.g. "https://grafana.example.com"
$env:Token           = ""           # Service account token (Editor+ privileges)
$env:Client_Name     = ""           # Display name, e.g. "Acme Corp"