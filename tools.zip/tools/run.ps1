# run.ps1
# -------
# Main entry point -> runs the full automation pipeline:
#
#   1. Load env vars     -> env.base.ps1
#   2. Build config      -> config.ps1
#   3. Create folder     -> create-folder.ps1  (ensures Clients/{ClientName}/ exists)
#   4. Update dashboard  -> update_sub_var.py  (copies + customizes the JSON)
#   5. Send dashboard    -> send-dashboard.ps1 (uploads to Grafana)
#
# Usage:
#   1. Fill in env.base.ps1 with your values
#   2. cd tools/
#   3. .\run.ps1
#
# Optional:
#   .\run.ps1 -DashboardKey home
#   .\run.ps1 -DashboardKey overview
#
# Prerequisites:
#   - "Clients" folder must already exist in Grafana
#   - Service account token with Editor+ privileges
#   - Python 3 installed (for update_sub_var.py)

param(
    # Optional override so you do not need to edit env.base.ps1 every time
    [string]$DashboardKey
)

$ErrorActionPreference = "Stop"

# Set-Location $PSScriptRoot -> ensures relative paths work from any directory
Set-Location $PSScriptRoot

Write-Host "============================================================"
Write-Host "Grafana Dashboard Automation"
Write-Host "============================================================"

# -- Step 1: Load environment variables -----------------------------------
# The dot-source operator (.) runs a script in the CURRENT scope
Write-Host "`n[1/5] Loading environment variables..."
. .\env.base.send.ps1

# If a flag was passed, let it override the environment variable.
# This gives you both options:
#   - set it once in env.base.ps1
#   - or swap dashboard types at runtime with -DashboardKey
if (-not [string]::IsNullOrWhiteSpace($DashboardKey)) {
    $env:Dashboard_Key = $DashboardKey.Trim().ToLower()
}


# -- Step 2: Build config -------------------------------------------------
Write-Host "[2/5] Building config..."
$config = . .\config.ps1

# Validate required fields makes sure that enviroment variables are not empty
if ([string]::IsNullOrWhiteSpace($config.GrafanaUrl))      { throw "GrafanaUrl is missing." }
if ([string]::IsNullOrWhiteSpace($config.Token))           { throw "Token is missing." }
if ([string]::IsNullOrWhiteSpace($config.ClientName))      { throw "ClientName is missing." }
if ([string]::IsNullOrWhiteSpace($config.SubscriptionId))  { throw "SubscriptionId is missing." }
if ([string]::IsNullOrWhiteSpace($config.DashboardsDir))   { throw "DashboardsDir is missing." }
if ([string]::IsNullOrWhiteSpace($config.DashboardKey))    { throw "DashboardKey is missing." }

Write-Host "  Client:       $($config.ClientName)"
Write-Host "  Subscription: $($config.SubscriptionId)"
Write-Host "  Grafana:      $($config.GrafanaUrl)"
Write-Host "  Dashboards:   $($config.DashboardsDir)"
Write-Host "  Template:     $($config.SourceDashboard)"
Write-Host "  Output:       $($config.OutputDashboard)"
Write-Host "  Dashboard:    $($config.DashboardTitle)"

# Ensure subdirectories exist. references the hashtable in config
foreach ($dir in @($config.TemplatesDir, $config.OutputDir, $config.PayloadsDir)) {
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
        Write-Host "  Created: $dir"
    }
}

# Sanity check -> fail early if the chosen template does not exist.
if (-not (Test-Path $config.SourceDashboard)) {
    throw "Source dashboard template not found: $($config.SourceDashboard)"
}

# -- Step 3: Create folder ------------------------------------------------
Write-Host "`n[3/5] Setting up folder: Clients/$($config.ClientName)..."
. .\create-folder.ps1 -Config $config

# -- Step 4: Update dashboard (Python) ------------------------------------
# Runs the Python script which reads the same env vars.
Write-Host "`n[4/5] Creating client dashboard copy..."
python .\update_sub_var.py

# $LASTEXITCODE -> the exit code of the last external program that ran
if ($LASTEXITCODE -ne 0) {
    throw "update_sub_var.py failed with exit code $LASTEXITCODE"
}

# -- Step 5: Send dashboard -----------------------------------------------
Write-Host "`n[5/5] Uploading dashboard to Grafana..."
. .\send-homepage.ps1 -Config $config

# -- Done -----------------------------------------------------------------
Write-Host "`n============================================================"
Write-Host "Done!"
Write-Host "============================================================"
