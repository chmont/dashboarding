# ==== CONFIG ====
$grafanaUrl = $env:Grafana_Url.TrimEnd('/')
$token = $env:Token

# ==== HEADERS ====
$headers = @{
    "Authorization" = "Bearer $token"
    "Content-Type"  = "application/json"
}

# ==== GET UID FROM HELPER SCRIPT ====
$r = .\get-dashboard-uids.ps1
$uid = $r.uid

if (-not [string]::IsNullOrWhiteSpace($uid)) {
    $uri = "$grafanaUrl/apis/dashboard.grafana.app/v1beta1/namespaces/default/dashboards/$uid"

    Write-Host "Checking dashboard...."
    $response = Invoke-RestMethod -Uri $uri -Headers $headers -Method Get
    $title = $response.spec.title

    Write-Host "Are you sure you want to delete: $title"

    do {
        $answer = (Read-Host "Type Y/Yes or N/No").Trim()

        if ($answer -match '^(?i)(y|yes)$') {
            Write-Host "Deleting dashboard: $title"
            Invoke-RestMethod -Uri $uri -Headers $headers -Method Delete
            Write-Host "Dashboard deleted successfully."
            $valid = $true
        }
        elseif ($answer -match '^(?i)(n|no)$') {
            Write-Host "Delete cancelled by user."
            $valid = $true
        }
        else {
            Write-Host "Invalid input. Please enter Y/y, YES/yes, N/n, or NO/no."
            $valid = $false
        }
    } until ($valid)
}
else {
    Write-Host "No matching dashboard UID was found."
}