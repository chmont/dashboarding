"""
update_sub_var.py
-----------------
Creates a client-specific copy of the selected base dashboard template.

The original file (in templates/) is NEVER modified. A new copy is written to:
    dashboards/output/{safe_name}-{dashboard_key}.json

Changes made to the copy:
  1. title       -> "{ClientName}-{DashboardLabel}"
  2. description -> "{ClientName}-{DashboardLabel}"
  3. uid         -> removed (Grafana assigns one on import)
  4. id          -> null (required for new dashboard creation)
  5. version     -> 0
  6. Template variable 'sub':
     - current.text  -> client name
     - current.value -> subscription ID
     - hide          -> 2 (fully hidden so users can't switch subscriptions)
     - query.subscription -> subscription ID
     - query.grafanaTemplateVariableFn.subscription -> subscription ID

Usage:
    Set environment variables before running (same ones the PowerShell scripts use):
        Client_Name     - e.g. "Acme Corp"
        Subscription    - Azure subscription ID
        Dashboards_Dir  - path to dashboards/ directory
        Dashboard_Key   - e.g. "overview" or "home"

    cd tools/
    python update_sub_var.py
"""

import json
import os
import re
import sys


# -- Configuration -------------------------------------------------------------

# Read from environment variables (matches env.base.ps1 variable names)
CLIENT_NAME = os.environ.get("Client_Name", "").strip()
SUBSCRIPTION_ID = os.environ.get("Subscription", "").strip()
DASHBOARDS_DIR = os.environ.get("Dashboards_Dir", "").strip()
DASHBOARD_KEY = os.environ.get("Dashboard_Key", "").strip().lower()
OVERWRITE = os.environ.get("True", "False").strip()


# Validate
missing = []
if not CLIENT_NAME:
    missing.append("Client_Name")
if not SUBSCRIPTION_ID:
    missing.append("Subscription")
if not DASHBOARDS_DIR:
    missing.append("Dashboards_Dir")
if not DASHBOARD_KEY:
    missing.append("Dashboard_Key")

if missing:
    print(f"ERROR: Missing environment variables: {', '.join(missing)}")
    sys.exit(1)

# safe_name: lowercase, only alphanumeric + hyphens, no leading/trailing hyphens
# Example: "Acme Corp" -> "acme-corp"
SAFE_NAME = re.sub(r"[^a-z0-9]+", "-", CLIENT_NAME.lower()).strip("-")

# Build the display label from the dashboard key.
# Example: overview -> Overview
#          home     -> Home
DASHBOARD_LABEL = DASHBOARD_KEY[:1].upper() + DASHBOARD_KEY[1:] if len(DASHBOARD_KEY) > 1 else DASHBOARD_KEY.upper()

# Paths using the dashboards directory structure
#   dashboards/
#     templates/    <- source of truth
#     output/       <- client-specific copies
SOURCE_PATH = os.path.join(DASHBOARDS_DIR, "templates", f"Client-{DASHBOARD_LABEL}.json")
OUTPUT_PATH = os.path.join(DASHBOARDS_DIR, "output", f"{SAFE_NAME}-{DASHBOARD_KEY}.json")

# Dashboard metadata
DASHBOARD_TITLE = f"{CLIENT_NAME}-{DASHBOARD_LABEL}"
DASHBOARD_DESC = f"{CLIENT_NAME}-{DASHBOARD_LABEL}"

# Variable visibility: 0 = visible, 1 = label only, 2 = fully hidden
HIDE_SUB_VARIABLE = 2


# -- Functions -----------------------------------------------------------------

def load_source_dashboard(path: str) -> dict:
    """Read the base dashboard JSON from disk."""
    if not os.path.isfile(path):
        print(f"ERROR: Source dashboard not found: {path}")
        sys.exit(1)

    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def update_metadata(dashboard: dict) -> None:
    """
    Update top-level dashboard fields. Modifies the dict in place.
      - title       -> {ClientName}-{DashboardLabel}
      - description -> {ClientName}-{DashboardLabel}
      - uid         -> removed entirely (Grafana assigns one)
      - id          -> None (null - tells API this is a new dashboard)
      - version     -> 0
    """
    dashboard["title"] = DASHBOARD_TITLE
    dashboard["description"] = DASHBOARD_DESC
    dashboard["id"] = None
    dashboard["version"] = 0
    dashboard.pop("uid", None)  # Remove uid so Grafana auto-assigns one


def update_subscription_variable(dashboard: dict) -> None:
    """
    Find the 'sub' template variable and update it for this client.

    The 'sub' variable controls which Azure subscription the dashboard queries.
    We set:
      - current.text/value -> client name and subscription ID
      - hide = 2           -> fully hidden from the dashboard UI
      - query.subscription -> locks the query to this subscription
    """
    template_list = dashboard.get("templating", {}).get("list", [])

    # Find the variable named "sub"
    # finds the sub key in the nested json
    # assigns it to sub_var for later manipulation
    sub_var = None
    for var in template_list:
        if var.get("name") == "sub":
            sub_var = var
            break

    if sub_var is None:
        print("ERROR: Could not find template variable 'sub' in dashboard JSON.")
        sys.exit(1)

    # current = what Grafana shows as the selected value on load
    sub_var["current"] = {
        "text": CLIENT_NAME,
        "value": SUBSCRIPTION_ID,
    }

    # Hide the dropdown so users can't switch subscriptions
    sub_var["hide"] = HIDE_SUB_VARIABLE

    # Update the query's subscription references
    query = sub_var.get("query", {})
    if isinstance(query, dict):
        query["subscription"] = SUBSCRIPTION_ID

        # Also update the nested grafanaTemplateVariableFn if present
        fn = query.get("grafanaTemplateVariableFn", {})
        if isinstance(fn, dict) and "subscription" in fn:
            fn["subscription"] = SUBSCRIPTION_ID


def save_dashboard(dashboard: dict, output_path: str) -> None:
    """Write the modified dashboard JSON to disk."""
    output_dir = os.path.dirname(output_path)
    if output_dir and not os.path.isdir(output_dir):
        os.makedirs(output_dir, exist_ok=True)

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(dashboard, f, indent=2, ensure_ascii=False)


# -- Main ----------------------------------------------------------------------

def main():
    print(f"Loading base dashboard: {SOURCE_PATH}")
    dashboard = load_source_dashboard(SOURCE_PATH)

    update_metadata(dashboard)
    update_subscription_variable(dashboard)

    save_dashboard(dashboard, OUTPUT_PATH)

    print("Client dashboard created:")
    print(f"  Dashboard key: {DASHBOARD_KEY}")
    print(f"  Title:         {DASHBOARD_TITLE}")
    print(f"  Description:   {DASHBOARD_DESC}")
    print(f"  Subscription:  {CLIENT_NAME} ({SUBSCRIPTION_ID})")
    print(f"  Hidden:        yes (hide={HIDE_SUB_VARIABLE})")
    print(f"  Output:        {OUTPUT_PATH}")


if __name__ == "__main__":
    main()
